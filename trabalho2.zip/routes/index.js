var express = require('express');
var router = express.Router();
var mysql = require('mysql');


function execSQLQuery(sqlQry) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'localhost',
            port: 3306,
            user: 'root',
            password: '',
            database: 'nodetest'
        });

        connection.query(sqlQry, function (error, results, fields) {
            if (error)
                reject(error)
            else
                resolve(results);
            connection.end();
        });
    });
}

/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', { title: 'Express' });
});

router.post("/registra", function (req, res, next) {
    const { name, cpf } = req.body;
    execSQLQuery(`INSERT INTO clientes(Nome, CPF) VALUES('${name}','${cpf}')`)
        .then(function () {
            res.render("registrado", {
                title: "Você está registrado",
                name,
                cpf
            });
        }).catch(function (err) {
            console.log(err);
            res.render("naoregistrado", {
                title: "Você não está registrado",
                name,
                cpf
            });
        });
});

router.post("/delete", function (req, res, next) {
    execSQLQuery(`DELETE FROM clientes WHERE cpf =` + req.body.cpf)
        .then(function () {
            res.render("deletado", {
                title: "Deletado com sucesso",

            });
        }).catch(function (err) {
            console.log(err);
            res.render("naodeletado", {
                title: "Você não foi deletado",

            });
        });
});


router.post("/consulta", function (req, res, next) {
    const { ID, name, cpf } = req.body;
    execSQLQuery(`SELECT * FROM clientes WHERE cpf= ` + cpf)
        .then(function (results) {
            console.log(results[0].CPF)
            res.render("um", {
                title: "Consultado",
                name: results[0].Nome,
                cpf: results[0].CPF
            });
        }).catch(function (err) {
            console.log(err);
            res.render("Erro", {
                title: "Erro",
                name,
                cpf
            });
        });
});

router.post("/consultaAll", function (req, res, next) {
    const { ID, name, cpf } = req.body;
    execSQLQuery(`SELECT * FROM clientes`)
        .then(function (results) {
            //console.log(results)
            res.render("all", {
                title: "Listar todos",
                results,
            });
        }).catch(function (err) {
            console.log(err);
            res.render("Erro", {
                title: "Erro",
                name,
                cpf
            });
        });
});

router.post("/update", function (req, res, next) {
    const { ID, name, cpf } = req.body;
    execSQLQuery(`UPDATE clientes SET Nome = '${name}', CPF = '${cpf}' WHERE ID ='${ID}'`)
        .then(function () {
            console.log()
            res.render("update", {
                title: "Atualização",
                name
            });
        }).catch(function (err) {
            console.log(err);
            res.render("Erro", {
                title: "Erro",
                name,
                cpf
            });
        });
});


module.exports = router;



